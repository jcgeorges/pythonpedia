
import subprocess
import sys
import threading
from datetime import datetime
import json
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
import secrets
from urllib.parse import urlsplit

app = Flask(__name__)

app.secret_key = secrets.token_hex(32)


@app.context_processor
def fournir_csrf():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(32)

    return {"csrf_token": session["csrf_token"]}

BASE_DIR = Path(__file__).resolve().parent
FICHIER_TOPICS = BASE_DIR / "data" / "topics.json"
FICHIER_SERVEURS = BASE_DIR / "data" / "serveurs.json"
SCRIPT_SYNCHRO = BASE_DIR / "services" / "synchronisation.py"

verrou_synchro = threading.Lock()

dernier_rapport = None

def lire_json(chemin):
    with open(chemin, "r", encoding="utf-8") as fichier:
        return json.load(fichier)


def enregistrer_json(chemin, donnees):
    with open(chemin, "w", encoding="utf-8") as fichier:
        json.dump(
            donnees,
            fichier,
            indent=4,
            ensure_ascii=False
        )

@app.route("/")
def accueil():
    # Charger les données actuelles
    topics = lire_json(FICHIER_TOPICS)
    serveurs = lire_json(FICHIER_SERVEURS)

    # Calculer les statistiques
    nombre_topics = len(topics)

    nombre_items = sum(
        len(items) for items in topics.values()
    )

    urls_uniques = set()
    statistiques_topics = []

    for nom, items in topics.items():
        urls_topic = set()

        for urls in items.values():
            urls_topic.update(urls)
            urls_uniques.update(urls)

        statistiques_topics.append({
            "nom": nom,
            "items": len(items),
            "urls": len(urls_topic)
        })

    statistiques_topics.sort(
        key=lambda x: x["urls"],
        reverse=True
    )

    statistiques = {
    "topics": nombre_topics,
    "nombre_items": nombre_items,
    "urls": len(urls_uniques),
    "serveurs": len(serveurs)
    }

    # Recherche d'un topic
    recherche = request.args.get("q", "").strip().lower()

    if recherche:
        topics_affiches = {
            nom: items
            for nom, items in topics.items()
            if recherche in nom.lower()
        }
    else:
        topics_affiches = topics

    return render_template(
    "dashboard.html",
    statistiques=statistiques,
    topics=topics_affiches,
    serveurs=serveurs,
    statistiques_topics=statistiques_topics,
    recherche=recherche,
    rapport_synchro=dernier_rapport
)


@app.route("/ajouter", methods=["POST"])
def ajouter_reference():

    # Vérification du formulaire
    token = request.form.get("csrf_token", "")

    if not secrets.compare_digest(
        token, session.get("csrf_token", "")
    ):
        abort(403)

    # Récupération des champs
    topic = request.form.get("topic", "").strip()
    item = request.form.get("item", "").strip()
    url = request.form.get("url", "").strip()

    # Vérification des informations
    adresse = urlsplit(url)

    if (
        not topic
        or not item
        or len(topic) > 100
        or len(item) > 100
        or not adresse.scheme in ("http", "https")
        or not adresse.netloc
        or not adresse.hostname
    ):
        flash("Informations invalides.")
        return redirect(url_for("accueil"))

    # Chargement de la base
    topics = lire_json(FICHIER_TOPICS)

    # Créer le topic si nécessaire
    if topic not in topics:
        topics[topic] = {}

    # Créer l'item si nécessaire
    if item not in topics[topic]:
        topics[topic][item] = []

    # Vérifier les doublons
    if url in topics[topic][item]:
        flash("Cette URL existe déjà dans cet item.")

    else:
        topics[topic][item].append(url)

        enregistrer_json(FICHIER_TOPICS, topics)

        flash("Référence ajoutée avec succès.")

    return redirect(url_for("accueil"))


@app.route("/synchroniser", methods=["POST"])
def lancer_synchronisation():
    global dernier_rapport

    # Vérifier le jeton CSRF
    token = request.form.get("csrf_token", "")

    if not secrets.compare_digest(
        token, session.get("csrf_token", "")
    ):
        abort(403)

    # Empêcher deux synchronisations simultanées
    if not verrou_synchro.acquire(blocking=False):
        flash("Une synchronisation est déjà en cours.")
        return redirect(url_for("accueil"))

    try:
        # Exécuter le script de synchronisation
        resultat = subprocess.run(
            [sys.executable, str(SCRIPT_SYNCHRO)],
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=360
        )

        sortie = resultat.stdout

        if resultat.stderr:
            sortie += "\n" + resultat.stderr

        dernier_rapport = {
            "date": datetime.now().strftime("%d/%m/%Y %H:%M"),
            "succes": resultat.returncode == 0,
            "message": sortie[-12000:]
        }

        if resultat.returncode == 0:
            flash("Synchronisation exécutée.")
        else:
            flash("La synchronisation a rencontré une erreur.")

    except subprocess.TimeoutExpired:
        dernier_rapport = {
            "date": datetime.now().strftime("%d/%m/%Y %H:%M"),
            "succes": False,
            "message": (
                "Délai maximal de 360 secondes dépassé. "
                "Vérifiez les serveurs inaccessibles."
            )
        }

        flash("La synchronisation a dépassé le délai autorisé.")

    except OSError as erreur:
        dernier_rapport = {
            "date": datetime.now().strftime("%d/%m/%Y %H:%M"),
            "succes": False,
            "message": str(erreur)
        }

        flash("Impossible de lancer la synchronisation.")

    finally:
        verrou_synchro.release()

    return redirect(url_for("accueil"))


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=5001,
        debug=False
    )
